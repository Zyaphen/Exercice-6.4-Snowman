﻿using SFML.Graphics;
using SFML.System;
using SFML.Window;
using System.Threading;
namespace Ex6._1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Créer la fenêtre d'une dimension 640 par 480
            const int LargeurMax = 800;
            const int HauteurMax = 600;
            VideoMode mode = new VideoMode(800, 600);
            RenderWindow fenetre = new RenderWindow(mode, "Vecteur Nowelle");

            // Créer le rectangle 
            //RectangleShape rectangle = new RectangleShape();
            //rectangle.Size = new Vector2f(200, 300);
            //rectangle.Position = new Vector2f(100, 100);
            //rectangle.FillColor = Color.Blue;
            //DECL var Input Output Draw
            Texture t = new Texture("Images/fond.png");
            Sprite s = new Sprite(t);
            s.Position = new Vector2f(0, 0);
            Vector2f PositionFond = s.Position;

            Texture t2 = new Texture("Images/traineau.png");
            Sprite s2 = new Sprite(t2);
            s2.Position = new Vector2f(500, 20);
            Vector2f PositionTraineau = s2.Position;

            Texture t3 = new Texture("Images/sapin.png");
            Sprite s3 = new Sprite(t3);
            s3.Position = new Vector2f(480, 250);
            Vector2f PositionSapin = s3.Position;

            Texture t4 = new Texture("Images/bonhomme.png");
            Sprite s4 = new Sprite(t4);
            s4.Position = new Vector2f(75, 375);
            Vector2f PositionBonhomme = s4.Position;

            Texture t5 = new Texture("Images/cadeau.png");
            Sprite s5 = new Sprite(t5);
            s5.Position = new Vector2f(480, 455);
            Vector2f PositionCadeau = s5.Position;
            while (fenetre.IsOpen /*&& PositionTraineau.X <= LargeurMax */ && !Keyboard.IsKeyPressed(Keyboard.Key.Escape))
            {
                fenetre.DispatchEvents();
                //fenetre.Clear(Color.Red);
                fenetre.Clear();
                fenetre.Draw(s);
                fenetre.Draw(s2);
                fenetre.Draw(s3);
                fenetre.Draw(s4);
                fenetre.Draw(s5);
                fenetre.Display();
                PositionTraineau = new Vector2f(PositionTraineau.X+1, PositionTraineau.Y);
                s2.Position = PositionTraineau;
                PositionSapin = new Vector2f(PositionSapin.X, PositionSapin.Y+1);
                s3.Position = PositionSapin;
                PositionBonhomme = new Vector2f(PositionBonhomme.X-1, PositionBonhomme.Y);
                s4.Position = PositionBonhomme;
                PositionCadeau = new Vector2f(PositionCadeau.X, PositionCadeau.Y-1);
                s5.Position = PositionCadeau;
                Thread.Sleep(10);
            }
            fenetre.Close();

        }
    }
}

//Compilez et testez le tout. Vous devriez voir apparaître la fenêtre suivante si tout va bien: