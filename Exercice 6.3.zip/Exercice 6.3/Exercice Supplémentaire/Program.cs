﻿using SFML.Graphics;
using SFML.System;
using SFML.Window;
using System.Threading;
using System;

namespace Ex6._1
{
    class Program
    {
        // Déclaration du tableau 2D de flocons
        enum Objet { Vide, Flocon };
        const int NbFlocons = 50;
        const int NbCases = 18;
        const int NbPixelsParCase = 32;
        const int TailleImage = NbCases * NbPixelsParCase;
        static void Main(string[] args)
        {
            // Créer la fenêtre d'une dimension 640 par 480
            VideoMode mode = new VideoMode(800, 600);
            RenderWindow fenetre = new RenderWindow(mode, "Vecteur Nowelle");

            //DECL var Input Output Draw
            Objet[,] tabFlocons = new Objet[NbCases, NbCases];
            //Initialiser le tableau de flocons
            for (int i = 0; i < NbCases; i++)        //i = Rangée;Rang++
            {
                for (int j = 0; j < NbCases; j++)    //J = Colonne;Col++
                {
                    //Placer les 50 flocons au hasard dans le tableau
                    tabFlocons[i, j] = Objet.Vide;
                }
            }
            Random random = new Random();
            int prochX;
            int prochY;
            int compteur = 0;

            while (compteur < NbFlocons)
            {
                prochX = random.Next(NbCases);
                prochY = random.Next(NbCases);
                if (tabFlocons[prochX, prochY] == Objet.Vide)
                {
                    tabFlocons[prochX, prochY] = Objet.Flocon;
                    ++compteur;
                }
            }
            //Déclaration et initialisation de la position du bonhomme de neige
            Texture t4 = new Texture("Images/bonhomme.png");
            Sprite s4 = new Sprite(t4);
            s4.Position = new Vector2f(0, 0);
            Vector2i PositionBonhomme = (Vector2i)s4.Position;
            //Déclaration et initialisation de la position du fond
            Texture t = new Texture("Images/fond.png");
            Sprite s = new Sprite(t);
            s.Position = new Vector2f(0, 0);
            Vector2f PositionFond = s.Position;

            Texture textureFlocon = new Texture("Images/flocon.png");

            //Créer la fenêtre
            //Charger les images en mémoire
            //Tant que la touche ESC n'est pas appuyée
            while (fenetre.IsOpen && !Keyboard.IsKeyPressed(Keyboard.Key.Escape))
            {
                Thread.Sleep(100);
                //   Vérifier si une touche a été appuyée
                //   Bouger le bonhomme de neige
                if (Keyboard.IsKeyPressed(Keyboard.Key.Up) && s4.Position.Y > 0)
                {
                    s4.Position = new Vector2f(s4.Position.X, s4.Position.Y - NbPixelsParCase);
                    PositionBonhomme = (Vector2i)s4.Position;
                }
                if (Keyboard.IsKeyPressed(Keyboard.Key.Down) && s4.Position.Y < TailleImage - NbPixelsParCase)
                {
                    s4.Position = new Vector2f(s4.Position.X, s4.Position.Y + NbPixelsParCase);
                    PositionBonhomme = (Vector2i)s4.Position;
                }
                if (Keyboard.IsKeyPressed(Keyboard.Key.Left) && s4.Position.X > 0)
                {
                    s4.Position = new Vector2f(s4.Position.X - NbPixelsParCase, s4.Position.Y);
                    PositionBonhomme = (Vector2i)s4.Position;
                }
                if (Keyboard.IsKeyPressed(Keyboard.Key.Right) && s4.Position.X < TailleImage - NbPixelsParCase)
                {
                    s4.Position = new Vector2f(s4.Position.X + NbPixelsParCase, s4.Position.Y);
                    PositionBonhomme = (Vector2i)s4.Position;
                }
                //   Effacer le flocon en dessous du bonhomme de neige
                tabFlocons[PositionBonhomme.X / NbPixelsParCase, PositionBonhomme.Y / NbPixelsParCase] = Objet.Vide;


                fenetre.DispatchEvents();
                fenetre.Clear();
                // Dessiner le fond
                fenetre.Draw(s);
                // Dessiner les flocons
                for (int i = 0; i < NbCases; i++)
                {
                    for (int j = 0; j < NbCases; j++)
                    {
                        if (tabFlocons[i, j] == Objet.Flocon)
                        {
                            Sprite flocon = new Sprite(textureFlocon);
                            flocon.Position = new Vector2f(i * NbPixelsParCase, j * NbPixelsParCase);
                            fenetre.Draw(flocon);
                        }
                    }
                }
                // Dessiner le bonhomme de neige
                fenetre.Draw(s4);
                // Rafraîchir la fenêtre
                fenetre.Display();
            }
            fenetre.Close();

        }
    }
}

//Compilez et testez le tout. Vous devriez voir apparaître la fenêtre suivante si tout va bien: